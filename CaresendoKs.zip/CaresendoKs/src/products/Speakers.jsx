const Speakers = () => {
  return (
    <>
      <h1>welcom to the spekaers page</h1>
    </>
  );
};

export default Speakers;
