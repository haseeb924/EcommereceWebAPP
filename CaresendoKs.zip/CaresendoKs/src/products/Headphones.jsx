const Headphones = () => {
  return (
    <>
      <h1>welcome to headphone page</h1>
    </>
  );
};

export default Headphones;
