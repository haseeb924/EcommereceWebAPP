const Earbuds = () => {
  return (
    <>
      <h1>welcome to earbuds</h1>
    </>
  );
};

export default Earbuds;

